package com.derraz.novaai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

data class UIMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: String,
    val content: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NovaAppScreen()
        }
    }
}

@Composable
fun NovaAppScreen() {
    val apiService = remember { NovaApiService.create() }
    val coroutineScope = rememberCoroutineScope()

    val bgCosmic = Color(0xFF040714)
    val cardBg = Color(0xFF0B1028)
    val userBubble = Color(0xFF4F46E5)

    var messages by remember {
        mutableStateOf(
            listOf(
                UIMessage(
                    role = "assistant",
                    content = "مرحباً بك في تطبيق NOVA AI على هاتفك! أنا جاهز لحل المسائل الرياضية، البرمجة، والتحليل العلمي. تطوير Derraz."
                )
            )
        )
    }
    var inputText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        containerColor = bgCosmic,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF070B1E))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF9333EA)))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("N", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("NOVA AI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("تطوير Derraz", color = Color(0xFF818CF8), fontSize = 11.sp)
                    }
                }

                Text(
                    text = "مسح",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            messages = listOf(
                                UIMessage(
                                    role = "assistant",
                                    content = "تم بدء جلسة جديدة. تفضل بسؤالك!"
                                )
                            )
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        },
        bottomBar = {
            Surface(
                color = Color(0xFF070B1E),
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .navigationBarsPadding()
                        .imePadding(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("اكتب رسالتك لـ NOVA AI...", color = Color.Gray, fontSize = 13.sp) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF0E1538),
                            unfocusedContainerColor = Color(0xFF0E1538),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(20.dp)),
                        maxLines = 4
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            val userText = inputText.trim()
                            if (userText.isNotEmpty() && !isLoading) {
                                inputText = ""
                                val updated = messages + UIMessage(role = "user", content = userText)
                                messages = updated
                                isLoading = true

                                coroutineScope.launch {
                                    try {
                                        val req = ChatRequest(
                                            messages = updated.map { MessagePayload(role = it.role, content = it.content) }
                                        )
                                        val res = apiService.sendChat(req)
                                        messages = messages + UIMessage(
                                            role = "assistant",
                                            content = res.reply ?: "تمت معالجة الطلب بنجاح."
                                        )
                                    } catch (e: Exception) {
                                        messages = messages + UIMessage(
                                            role = "assistant",
                                            content = "⚠️ تعذر الاتصال بالخادم، تحقق من اتصال الإنترنت."
                                        )
                                    } finally {
                                        isLoading = false
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .background(
                                Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF7C3AED))),
                                shape = CircleShape
                            )
                    ) {
                        Text("➔", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                val isUser = msg.role == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .widthIn(max = 300.dp)
                            .clip(
                                RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isUser) 16.dp else 4.dp,
                                    bottomEnd = if (isUser) 4.dp else 16.dp
                                )
                            )
                            .background(if (isUser) userBubble else cardBg)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = msg.content,
                            color = Color.White,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            textAlign = TextAlign.Start
                        )
                    }
                }
            }

            if (isLoading) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(cardBg)
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text("⏳ NOVA AI يحلل ويكتب...", color = Color(0xFFA5B4FC), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
