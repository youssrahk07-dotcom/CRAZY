package com.derraz.novaai

import com.google.gson.annotations.SerializedName
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

data class MessagePayload(
    @SerializedName("role") val role: String,
    @SerializedName("content") val content: String
)

data class ChatRequest(
    @SerializedName("messages") val messages: List<MessagePayload>,
    @SerializedName("model") val model: String = "gemini-2.5-flash"
)

data class ChatResponse(
    @SerializedName("reply") val reply: String?
)

interface NovaApiService {
    @POST("api/chat")
    suspend fun sendChat(@Body request: ChatRequest): ChatResponse

    companion object {
        private const val BASE_URL = "https://ais-pre-5rfb7w6lvroz3l5jstkrcr-254186430667.europe-west3.run.app/"

        fun create(): NovaApiService {
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(NovaApiService::class.java)
        }
    }
}
